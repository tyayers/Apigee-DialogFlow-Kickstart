 var mock = {
    status: "UP"
}

context.proxyResponse.content = JSON.stringify(mock);
