var requestContent = JSON.parse(context.getVariable("request.content"));

print(context.getVariable("request.content"));

var alertCount = 0;
var machine = "";
var message = "\"Your services are operating normally.\"";
var submessage = "\"All machines are operational\"";
var image = "https://storage.googleapis.com/bruno-hosting/smart-factory/good_pin.svg";

var randNumber = getRandomIntInclusive(1, 100);
var statusArray = [];

if (randNumber % 2 == 0) {
    statusArray = 
    [
        {
            ErrorsLastFiveMinutes: getRandomIntInclusive(0, 3),
            WarningsLastFiveMinutes: getRandomIntInclusive(0, 5)
        }
    ];
}

for (i=0; i<statusArray.length; i++) {
    var newStatus = statusArray[i];
    if (parseInt(newStatus.ErrorsLastFiveMinutes) > 0) {
        // We have an alert in the last five minutes...
        alertCount++;
        image = "https://storage.googleapis.com/bruno-hosting/smart-factory/error_pin.svg";
        machine = "SAP System " + getRandomIntInclusive(100, 400);
    }
    
    if (parseInt(newStatus.WarningsLastFiveMinutes) > 0) {
        // We have an alert in the last five minutes...
        alertCount++;
        image = "https://storage.googleapis.com/bruno-hosting/smart-factory/warning_pin.svg";
        machine = "SAP System " + getRandomIntInclusive(100, 400);
    }    
}

if (alertCount == 1) {
    message = "\"Your services have " + alertCount + " active alert from system " + machine + ". Please check your Smart Monitoring app for more information. Anything else?\"";
    submessage = "\"Alert: " + machine + "\"";
}
else if (alertCount > 1) {
    message = "\"Your services have " + alertCount + " active alerts from system " + machine + ". Please check your Smart Monitoring app for more information. Anything else?\"";
    submessage = "\"Alert: " + machine + "\"";    
}

response.content = '';
response.headers['Content-Type'] = 'application/json';
var body = response.content.asJSON;

body.fulfillmentMessages = [];

var googlePayload = {
    "payload": {
        "google": {
            "expectUserResponse": true,
            "richResponse": {
                "items": []
            }
        }
    }
    
}

var defaultPayload = {
    "payload": {
        "richContent": [[]]
    }    
};

body.fulfillmentMessages.push(defaultPayload);
body.fulfillmentMessages.push(googlePayload);

body.fulfillmentMessages.push({
             "card": {
                "title": message,
                "subtitle": submessage,
                "imageUri": image
            }
        });
        
body.fulfillmentMessages[0].payload.richContent[0].push({
            "type": "info",
            "title": message,
            "subtitle": submessage,
            "image": {
              "src": {
                "rawUrl": image
                }
            },
            "actionLink": "https://google.com"
        });
        
body.fulfillmentMessages[1].payload.google.richResponse.items.push({
            "basicCard": 
            {
                "title": message,
                "subtitle": submessage,
                "image": {
                     "url": image
                }
            }
        });

body.fulfillmentText = message;
body.fulfillmentMessages[1].payload.google.richResponse.items.unshift(                    {
    "simpleResponse": {
        "textToSpeech": message
    }
});


function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min); //The maximum is inclusive and the minimum is inclusive
}
